# custom_logger/__init__.py
from .custom_logger import setup_custom_logger